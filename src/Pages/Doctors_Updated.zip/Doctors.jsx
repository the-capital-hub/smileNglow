import React, { useMemo, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import "./Doctors.css";

import adithya from "../../assets/docotor/adithya.png";
import andesh from "../../assets/docotor/andesh.png";
import kiran from "../../assets/docotor/kiran.png";
import martin from "../../assets/docotor/martin.png";
import rajio from "../../assets/docotor/rajio.png";
import sahar from "../../assets/docotor/sahar.png";
import sanketh from "../../assets/docotor/sanketh.png";
import sarfaraz from "../../assets/docotor/sarfaraz.png";
import sushant from "../../assets/docotor/sushant.png";
import yajwin from "../../assets/docotor/yajwin.png";

const doctors = [
  { id: "kiran", name: "Dr. Kiran Sunny", role: "Resident Doctor", specialty: "Prosthodontics", qualification: "BDS, MDS • Prosthodontist", description: "Focused on thoughtful treatment planning and long term oral health.", image: kiran, branches: ["HSR", "Jayanagar", "Silk Institute"], category: "resident" },
  { id: "sarfaraz", name: "Dr. Sarfaraz", role: "Resident Doctor", specialty: "General Dentistry", qualification: "BDS", description: "Supporting everyday dental health through preventive and restorative care.", image: sarfaraz, branches: ["HSR"], category: "resident" },
  { id: "vaishak", name: "Dr. Vaishak", role: "Resident Doctor", specialty: "General Dentistry", qualification: "BDS", description: "Dedicated to clear guidance and comfortable dental visits.", image: null, branches: ["Jayanagar"], category: "resident" },
  { id: "raijo", name: "Dr. Raijo Thomas", role: "Resident Doctor", specialty: "General Dentistry", qualification: "BDS", description: "Dedicated to clear guidance and comfortable dental visits.", image: rajio, branches: ["Silk Institute"], category: "resident" },
  { id: "sushant", name: "Dr. Sushant", role: "Consultant", specialty: "Oral Surgery", qualification: "BDS, MDS • Oral Surgeon", description: "Supporting patients through oral surgery with attentive care.", image: sushant, branches: ["HSR", "Jayanagar", "Silk Institute"], category: "consultant" },
  { id: "sanket", name: "Dr. Sanket", role: "Consultant", specialty: "Orthodontics", qualification: "BDS, MDS • Orthodontist", description: "Helping patients work toward healthier bites and confident smiles.", image: sanketh, branches: ["HSR", "Jayanagar", "Silk Institute"], category: "consultant" },
  { id: "martin", name: "Dr. Martin", role: "Consultant", specialty: "Endodontics", qualification: "BDS, MDS • Endodontist", description: "Focused on preserving natural teeth and easing dental discomfort.", image: martin, branches: ["HSR", "Jayanagar", "Silk Institute"], category: "consultant" },
  { id: "sai-kalyan", name: "Dr. Sai Kalyan", role: "Consultant", specialty: "Dental Care", qualification: "", description: "Dedicated to providing attentive and patient focused dental care.", image: null, branches: ["HSR"], category: "consultant" },
  { id: "sahar", name: "Dr. Sahar", role: "Consultant", specialty: "Periodontics", qualification: "BDS, MDS • Periodontist", description: "Focused on gum health and the care of supporting tissues.", image: sahar, branches: ["HSR", "Jayanagar"], category: "consultant" },
  { id: "kalyan", name: "Dr. Kalyan", role: "Consultant", specialty: "Dental Care", qualification: "", description: "Dedicated to providing attentive and patient focused dental care.", image: null, branches: ["Jayanagar", "Silk Institute"], category: "consultant" },
  { id: "yajwin", name: "Dr. Yajwin", role: "Consultant", specialty: "Orthodontics", qualification: "BDS, MDS • Orthodontist", description: "Helping patients work toward healthier bites and confident smiles.", image: yajwin, branches: ["Jayanagar"], category: "consultant" },
  { id: "sandesh", name: "Dr. Sandesh", role: "Consultant", specialty: "Orthodontics", qualification: "BDS, MDS • Orthodontist", description: "Helping patients work toward healthier bites and confident smiles.", image: null, branches: ["Silk Institute"], category: "consultant" },
  { id: "aditya", name: "Dr. Aditya", role: "Consultant", specialty: "Endodontics", qualification: "BDS, MDS • Endodontist", description: "Focused on caring treatment for tooth pain and root canal needs.", image: adithya, branches: ["Silk Institute"], category: "consultant" },
];

const branches = ["HSR", "Jayanagar", "Silk Institute"];

const reveal = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
};

function Doctors() {
  const shouldReduceMotion = useReducedMotion();
  const [activeBranch, setActiveBranch] = useState("HSR");
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  const branchDoctors = useMemo(
    () => doctors.filter((doctor) => doctor.branches.includes(activeBranch)),
    [activeBranch]
  );
  const residents = branchDoctors.filter((doctor) => doctor.category === "resident");
  const consultants = branchDoctors.filter((doctor) => doctor.category === "consultant");

  const cardVariants = shouldReduceMotion
    ? { hidden: { opacity: 1 }, visible: { opacity: 1 } }
    : reveal;

  const renderDoctorCards = (list) =>
    list.map((doctor, index) => (
      <motion.article
        className="doctor-card"
        key={doctor.id}
        variants={cardVariants}
        custom={index}
        whileHover={shouldReduceMotion ? undefined : { y: -5 }}
        layout
      >
        <button
          className="doctor-card-open"
          type="button"
          onClick={() => setSelectedDoctor(doctor)}
          aria-label={`View profile of ${doctor.name}`}
        >
          <span className="doctor-image">
            {doctor.image ? (
              <img src={doctor.image} alt={doctor.name} loading="lazy" />
            ) : (
              <span className="doctor-image-placeholder">
                <span className="placeholder-mark" aria-hidden="true">＋</span>
                <span>Smile and Glow Vasan</span>
              </span>
            )}
          </span>
          <span className="doctor-plus" aria-hidden="true">＋</span>
          <span className="doctor-content">
            <span className="doctor-specialty">{doctor.specialty}</span>
            <strong className="doctor-name">{doctor.name}</strong>
            <span className="doctor-role">{doctor.role}</span>
            {doctor.qualification && <span className="doctor-qualification">{doctor.qualification}</span>}
            <span className="doctor-branch-chip">● {activeBranch}</span>
          </span>
        </button>
      </motion.article>
    ));

  const renderDoctorSection = (title, list) => {
    if (!list.length) return null;
    return (
      <section className="doctor-category-section" aria-label={title}>
        <h3 className="doctor-category-title">{title}</h3>
        <motion.div
          className="doctors-grid"
          variants={{ hidden: {}, visible: { transition: { staggerChildren: shouldReduceMotion ? 0 : 0.07 } } }}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.06 }}
        >
          {renderDoctorCards(list)}
        </motion.div>
      </section>
    );
  };

  return (
    <main className="doctors-page">
      <motion.section className="doctors-hero" variants={cardVariants} initial="hidden" animate="visible">
        <div className="doctors-hero-content">
          <p className="doctors-breadcrumb"><span>Home</span><span className="breadcrumb-separator">›</span><span>Doctors</span></p>
          <h1>Our <span>Doctors</span></h1>
          <h2>Meet the people behind your healthier smile.</h2>
          <p className="doctors-hero-description">
            From your first consultation to your follow up care, our dental team is here to make every visit feel comfortable, clear, and personal.
          </p>
          <a className="doctors-book-button" href="/contact"><span aria-hidden="true">▦</span>Book an Appointment</a>
        </div>
      </motion.section>

      <section className="doctors-team-section">
        <motion.div className="doctors-benefits" variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.1 } } }} initial="hidden" whileInView="visible" viewport={{ once: true }}>
          {[
            ["♧", "Experienced Team", "Specialists across key dental fields"],
            ["◇", "Patient First Care", "Comfort, safety, and clear guidance"],
            ["♡", "Comprehensive Care", "From prevention to advanced treatments"],
            ["♡", "Trusted by Patients", "For quality care and lasting smiles"],
          ].map(([icon, title, description]) => (
            <motion.article className="doctors-benefit" variants={cardVariants} key={title}>
              <span className="benefit-icon" aria-hidden="true">{icon}</span>
              <div><h3>{title}</h3><p>{description}</p></div>
            </motion.article>
          ))}
        </motion.div>

        <motion.header className="doctors-section-header" variants={cardVariants} initial="hidden" whileInView="visible" viewport={{ once: true }}>
          <span className="doctors-eyebrow">Clinical Team</span>
          <h2>Specialists You Can <span>Trust</span></h2>
          <p>Click on any doctor to view their profile, qualifications, and area of expertise.</p>
        </motion.header>

        <div className="doctors-branch-selector" aria-label="Filter doctors by branch">
          <span className="branch-filter-label">Filter by branch</span>
          {branches.map((branch) => (
            <button
              key={branch}
              type="button"
              className={`doctors-branch-button ${activeBranch === branch ? "active" : ""}`}
              onClick={() => setActiveBranch(branch)}
              aria-pressed={activeBranch === branch}
            >
              {branch}<span className="branch-count">{doctors.filter((doctor) => doctor.branches.includes(branch)).length}</span>
            </button>
          ))}
        </div>

        <div className="doctors-branch-heading">
          <h2>{activeBranch}</h2>
          <p>Meet our dental care team</p>
        </div>

        {renderDoctorSection("Resident Doctors", residents)}
        {renderDoctorSection("Consultants", consultants)}

        <motion.section className="doctors-cta" variants={cardVariants} initial="hidden" whileInView="visible" viewport={{ once: true }}>
          <div className="doctors-cta-decoration" aria-hidden="true">♡</div>
          <div className="doctors-cta-content">
            <span className="doctors-cta-eyebrow">YOUR SMILE MATTERS</span>
            <h2>Ready for a Healthier <span>Smile?</span></h2>
            <p>Book a consultation with our dental care team at the {activeBranch} branch.</p>
          </div>
          <div className="doctors-cta-features">
            <div className="doctors-cta-feature"><span aria-hidden="true">▦</span><p>Easy Booking</p></div>
            <div className="doctors-cta-feature"><span aria-hidden="true">◇</span><p>Trusted Experts</p></div>
            <div className="doctors-cta-feature"><span aria-hidden="true">♡</span><p>Personalized Care</p></div>
          </div>
          <a href="/contact" className="doctors-cta-button">Book an Appointment <span aria-hidden="true">→</span></a>
        </motion.section>
      </section>

      <AnimatePresence>
        {selectedDoctor && (
          <motion.div
            className="doctor-modal-backdrop"
            role="presentation"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onMouseDown={(event) => {
              if (event.target === event.currentTarget) setSelectedDoctor(null);
            }}
          >
            <motion.section
              className="doctor-modal"
              role="dialog"
              aria-modal="true"
              aria-labelledby="doctor-modal-name"
              initial={shouldReduceMotion ? false : { opacity: 0, y: 24, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 18, scale: 0.97 }}
            >
              <button className="doctor-modal-close" type="button" onClick={() => setSelectedDoctor(null)} aria-label="Close profile">×</button>
              <div className="doctor-modal-image">
                {selectedDoctor.image ? <img src={selectedDoctor.image} alt={selectedDoctor.name} /> : <div className="doctor-image-placeholder"><span className="placeholder-mark">＋</span><span>Smile and Glow Vasan</span></div>}
              </div>
              <div className="doctor-modal-content">
                <span className="doctor-specialty">{selectedDoctor.specialty}</span>
                <h2 id="doctor-modal-name">{selectedDoctor.name}</h2>
                <p className="doctor-modal-role">{selectedDoctor.role}</p>
                {selectedDoctor.qualification && <p><strong>Qualification:</strong> {selectedDoctor.qualification}</p>}
                <p>{selectedDoctor.description}</p>
                <div className="doctor-modal-branches"><strong>Available at</strong><div>{selectedDoctor.branches.map((branch) => <span key={branch}>{branch}</span>)}</div></div>
                <a className="doctors-book-button" href="/contact">Book an Appointment <span aria-hidden="true">→</span></a>
              </div>
            </motion.section>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}

export default Doctors;
